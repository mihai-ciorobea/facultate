<?php
$con=mysqli_connect("localhost","root","","faceted_search");
// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }


$facetValueID = $_POST[facetValueID];
$facetID = $_POST[facetID];  
$facetValueName = $_POST[facetValueName];
$defaultRank = $_POST[defaultRank];

$sql =	"UPDATE FacetValues 
		SET Name = '$facetValueName', FacetID = '$facetID', DefaultRank = '$defaultRank'
		WHERE FacetValueID = '$facetValueID'";
		
if (!mysqli_query($con,$sql))
  {
  die('Error: ' . mysqli_error($con));
  }
  

echo "OK";

mysqli_close($con);
?>