

//TODO: verify that we don;t add duplicate facets 
//mesaje de eroare ( si la celelalte pagini daca e cazul) + response codes la php-uri
//TODO: add posibility to modify facet/facet-value name by double-clicking on the name
//make the text box for a facet dissapear on mouseover
//expand the facet when adding a facet value
//clear the textbox after enter
//show a popup when deleting something
//show popup when save

var idIndex = 0;
var deletedFacetIDs = [];
var deletedFacetValueIDs = []; 


$( document ).ready(function() {

	loadFacetsAndFacetValues();

	$('#newFacetName').keyup(function(e){
		if(e.keyCode == 13)
		{
		  addNewFacet($('#newFacetName').val());
		}
	});

});

function setFacetEvents(liFacetID) {

	setSortableFacetsEvents(liFacetID);
	setToggleEvents(liFacetID);
	setButtonEvents(liFacetID);
}

function setFacetValueEvents(liFacetValueID) {

	setSortableFacetValuesEvents(liFacetValueID);
	setButtonEvents(liFacetValueID);
}

function setSortableFacetsEvents(liFacetID) {

	$(liFacetID).find('a').mouseover(function() {
 		$('#facetsList').sortable();
	});
}

function setSortableFacetValuesEvents(liFacetValueID) {

	$(liFacetValueID).mouseover(function() {
		$('#facetsList').sortable('destroy');
	});
	$(liFacetValueID).parent().sortable();
}

function setToggleEvents(liFacetID) {

	$(liFacetID+' ul').hide();
   	$(liFacetID + ' .facetName').click(function() {
		$(this).parent().find('ul').toggle();
	});
}

function setButtonEvents(liID) {

	$($(liID+' .delete')[0]).hide();
	$($(liID+' .add')[0]).hide();
	$($(liID+' input')[0]).hide();
	
	
	$(liID).mouseover ( function(){

		$($(liID+' .delete')[0]).show();
		$($(liID+' .add')[0]).show();
	});

	$(liID).mouseout ( function(){

		$($(liID+' .delete')[0]).hide();
		$($(liID+' .add')[0]).hide();
	});

}

function loadFacetsAndFacetValues() {

		$.ajax({
        type: "get",
        url: "getFacets.php?",
        dataType : 'text/html',
        
        statusCode: {
		    200: function(data) {
		    		
		    		var facetArray = JSON.parse(data.responseText);
					$(facetArray).each(function( index, element ) {
						addFacetHtml(element.FacetID, element.Name);
						loadFacetValues(element.FacetID);						
					});
			    }
			  }             
   		});
}

function addFacetHtml(facetID, facetName) {

	$("#facetsList").append(
						'<li " id=f'+facetID+'><a class="facetName"><span>'+facetName+'</span></a>\
			              <a class="delete"  href="#" onclick="deleteFacet('+"'" +facetID+"'"+')"><img src="images/remove.png"></a>\
			              <a class="add"  href="#" onclick="addNewFacetValue('+"'"+facetID+"'"+')"><img src="images/add.png"></a>\
			              <input class="inputNewFacet" id="inf'+facetID+'" type="text">\
			              <ul>\
			              </ul>\
			            </li>');
	$("#facetsList #f" + facetID).mouseleave(hideAllinputs);
	setFacetEvents("#f"+facetID);

}

function loadFacetValues(facetID) {

	$.ajax({
        type: "get",
        url: "getFacetValues.php?facetID="+facetID,
        dataType : 'text/html',
        
        statusCode: {
		    200: function(data) {
		    		
		    		var facetValuesArray = JSON.parse(data.responseText);
					$(facetValuesArray).each(function( index, element ) {
						addFacetValueHtml(facetID, element.FacetValueID, element.Name);					
					});	
			    }
			  }             
   		});
}

function addFacetValueHtml(facetID, facetValueID, facetValueName) {

	$("#f"+facetID+" ul").append(
							'<li class="facetValues" id=fv'+facetValueID+'><span>'+facetValueName+'</span>\
							 <a class="delete" href="#" onclick="deleteFacetValue('+"'"+facetValueID+"'"+')">\
							  <img src="images/remove.png">\
							 </a>\
							</li>');

	setFacetValueEvents("#fv"+facetValueID);
}

function addNewFacet(facetName) {

	//TODO: error message
	if ( $.trim(facetName) == "" )
		return;

	idIndex++;
	addFacetHtml("n"+idIndex, facetName);	
	$('#fn'+ idIndex).addClass("newFacet");
}

function hideAllinputs(){
	$("[id^='inf']").hide();
}


function addNewFacetValue(facetID) {


//TODO: this has bugs; fix them :)) (when does the input appear & dissapear)
//TODO: expand the ul if it's collapsed when adding a new facet value

	$('#inf'+facetID).show();
	$('#inf'+facetID).focus();
/*
	$('#inf'+facetID).show();
	$('#f'+facetID).mouseover ( function(){
		$('#inf'+facetID).show();
	});

	$('#f'+facetID).mouseout ( function(){
		$('#inf'+facetID).hide();
		$('#f'+facetID).removeAttr("mouseover");
		setButtonEvents('#f'+facetID);
	});
*/
	$('#inf'+facetID).keyup(function(e){
		if(e.keyCode == 13)
		{
			var facetValueName = $('#inf'+facetID).val();
			$('#inf'+facetID).val("");
		
			if ( $.trim(facetValueName) == "" ) {
				$('#inf'+facetID).hide();
				return;
			}

			idIndex++;
			addFacetValueHtml(facetID, "n"+idIndex, facetValueName);
			$('#fvn'+ idIndex).addClass("newFacetValue");			
			$('#inf'+facetID).hide();
			
			//$('#f'+facetID).removeAttr("mouseover");
			//setButtonEvents('#f'+facetID);
		}
	});
}

function deleteFacet(facetID) {
	$('#f'+facetID).remove();
	deletedFacetIDs.push(facetID);
}

function deleteFacetValue(facetValueID) {
	$('#fv'+facetValueID).remove();
	deletedFacetValueIDs.push(facetValueID);
}

function deleteFacetsAndFacetValues() {

	$.ajax({
        type: "post",
        url: "deleteFacets.php?",
        dataType : 'text/html',
        data: { facetIDs : deletedFacetIDs },
    });

	$.ajax({
        type: "post",
        url: "deleteFacetValues.php?",
        dataType : 'text/html',
        data: { facetValueIDs : deletedFacetValueIDs },
    });
}

//TODO: the facets&facet-values that have been deleted
function saveHierarchy() {

	deleteFacetsAndFacetValues();

	$('#facetsList').children('li').each(function (index, element) {

		var facetName = $($(element).find('span')[0]).text();
	
		if ( $(element).hasClass('newFacet') ) {

			console.log(facetName);

			$.ajax({
		        type: "post",
		        url: "addFacet.php",
		        dataType : 'text/html',
		        data: { facetName : facetName, defaultRank : index },

		        statusCode: {
				    200: function(data) {
				    		
				    		var facetID = data.responseText;
							saveFacetValuesHierarchy(facetID, element);
					    }
					  }             
		    });
		}
		else {
			updateFacet($(element).attr('id').substring(1), facetName, index, element);
		}

	});
	
}

function updateFacet(facetID, facetName, index, element) {

	$.ajax({
        type: "post",
        url: "updateFacet.php",
        dataType : 'text/html',
        data: { facetID : facetID, facetName : facetName, defaultRank : index },

        statusCode: {
		    200: function(data) {
		    		
					saveFacetValuesHierarchy(facetID, element);
			    }
			  }             
    });

}

function saveFacetValuesHierarchy(facetID, element) {

	$(element).find('li').each(function (index, element) {

		var facetValueName = $($(element).find('span')[0]).text();
	
		if ( $(element).hasClass('newFacetValue') ) {

			$.ajax({
		        type: "post",
		        url: "addFacetValue.php",
		        dataType : 'text/html',
		        data: { facetID : facetID, facetValueName : facetValueName, defaultRank : index },        
		    });
		}
		else {
			
			var facetValueID = $(element).attr('id').substring(2);
			$.ajax({
		        type: "post",
		        url: "updateFacetValue.php",
		        dataType : 'text/html',
		        data: { facetValueID : facetValueID, facetID : facetID, facetValueName : facetValueName, defaultRank : index },         
		    });
		}

	});

}

function cancelHierarchy() {
	location.reload();
}





