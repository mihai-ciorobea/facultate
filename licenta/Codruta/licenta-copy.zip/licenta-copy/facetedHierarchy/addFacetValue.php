<?php
$con=mysqli_connect("localhost","root","","faceted_search");
// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }


$facetID = $_POST[facetID];  
$facetValueName = $_POST[facetValueName];
$defaultRank = $_POST[defaultRank];

$sql =	"INSERT INTO FacetValues (Name, FacetID, DefaultRank)
		VALUES
		('$facetValueName', '$facetID', '$defaultRank')";

if (!mysqli_query($con,$sql))
  {
  die('Error: ' . mysqli_error($con));
  }
  

echo "OK";

mysqli_close($con);
?>