<?php
$con=mysqli_connect("localhost","root","","faceted_search");
// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }


$facetIDs = $_POST[facetIDs];

if ( count($facetIDs) == 0 )
  return;

$list = "(";
foreach ($facetIDs as &$value) {
    $list = $list . $value . ',';
}
$list = substr($list, 0, strlen($list) - 1 );
$list = $list . ")";


$sql =	"DELETE FROM Facets WHERE FacetID in $list";

if (!mysqli_query($con,$sql))
  {
  die('Error: ' . mysqli_error($con));
  }
  
echo "OK";

mysqli_close($con);
?>