<?php
$con=mysqli_connect("localhost","root","","faceted_search");
// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }

$facetID = $_GET[facetID];

$sql =	"SELECT FacetValueID, Name FROM FacetValues WHERE FacetID = $facetID order by DefaultRank";

$result = mysqli_query($con,$sql);
if (!$result)
  {
  die('Error: ' . mysqli_error($con));
  }

$facetValuesArray = array();
$index = 0;
while($row = mysqli_fetch_assoc($result)) {
     $facetValuesArray[$index] = $row;
     $index++;
}

echo json_encode($facetValuesArray);

mysqli_close($con);
?>