

$( document ).ready(function() {

    showLogin();

});


function showLogin() {
    
    $('#register').hide();
    $('#login').show();
}

function showRegister() {
    
    $('#login').hide();
    $('#register').show();
}

function login() {

    $.ajax({
        type: "POST",
        url: "login.php",
        data: { username : $('#login_username').val(),
                password :  $('#login_password').val()},
        dataType : 'text/html',
        
        statusCode: {
            200: function(data) {
                    var response = JSON.parse(data.responseText);
                
                    if ( response.Type == 0 )
                        window.location.href = "../facetedSearch/index.html?userID="+response.UserID;
                    else 
                        window.location.href = "../manageProducts";
                },
            401: function(data) {
               $('#wrong').show();
               $('#wrong').fadeOut(2000);
            }    

        }             
    });

}

function register() {

    if ($('#register_password').val() != $('#register_password_confirmation').val()) {

        $('#register_password').val('');
        $('#register_password_confirmation').val('');
        $('#passMatch').show();
        $('#passMatch').fadeOut(2000);
        return;
    }
     
    $.ajax({
        type: "POST",
        url: "register.php",
        data: { username : $('#register_username').val(),
                password :  $('#register_password').val(),
                name : $('#register_name').val(),
                address : $('#register_address').val(),
                sex : $('input[name="sex"]:checked').val() },
        dataType : 'text/html',
        
        statusCode: {
            200: function(data) {
                    var response = JSON.parse(data.responseText);
                    window.location.href = "../facetedSearch/index.html?userID="+response.UserID;
                },
            401: function(data) {
                $('#register_username').val('');
                $('#existingUesr').show();
                $('#existingUesr').fadeOut(2000);
            }   
        }             
    });
}
