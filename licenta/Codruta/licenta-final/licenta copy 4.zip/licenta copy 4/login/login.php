<?php
$con=mysqli_connect("localhost","root","","faceted_search");
// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }


$username = $_POST[username];
$password = $_POST[password];


	$sql = "SELECT * FROM Users WHERE Username = '$username' AND Password = '$password'";
	$result = mysqli_query($con,$sql);
	if (!$result)
	  {
	  die('Error: ' . mysqli_error($con));
	  }  


	if(mysqli_num_rows($result)) {
		$row = mysqli_fetch_assoc($result);
		 header('HTTP/1.1 200 OK', true, 200);
		 echo json_encode($row);
	}
	else {
		 header('HTTP/1.1 401 Unauthorized', true, 401);
		 return;
	}

mysqli_close($con);
?>