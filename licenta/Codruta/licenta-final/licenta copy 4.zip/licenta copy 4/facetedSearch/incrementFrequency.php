<?php
$con=mysqli_connect("localhost","root","","faceted_search");
// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }


$userID = $_GET[userID];
$facetID = $_GET[facetID];
$facetValueID = $_GET[facetValueID];

$sql = "SELECT 1 FROM FacetRanks WHERE UserID = $userID and FacetID = $facetID";
$result = mysqli_query($con,$sql);
if (!$result)
  {
  die('Error: ' . mysqli_error($con));
  }  


if(mysqli_num_rows($result)) {
  $sql =  "UPDATE FacetRanks SET Frequency = Frequency + 1 WHERE UserID=$userID and FacetID=$facetID";
  $result = mysqli_query($con,$sql);
  if (!$result)
    {
    die('Error: ' . mysqli_error($con));
    }
}
else {
  $sql =  "INSERT INTO FacetRanks(UserID,FacetID,Frequency) VALUES($userID, $facetID, 1)";
  $result = mysqli_query($con,$sql);
  if (!$result)
    {
    die('Error: ' . mysqli_error($con));
    }
}


$sql = "SELECT 1 FROM FacetValueRanks WHERE UserID = $userID and FacetValueID = $facetValueID";
$result = mysqli_query($con,$sql);
if (!$result)
  {
  die('Error: ' . mysqli_error($con));
  }  


if(mysqli_num_rows($result)) {
  $sql =  "UPDATE FacetValueRanks SET Frequency = Frequency + 1 WHERE UserID=$userID and FacetValueID=$facetValueID";
  $result = mysqli_query($con,$sql);
  if (!$result)
    {
    die('Error: ' . mysqli_error($con));
    }
}
else {
  $sql =  "INSERT INTO FacetValueRanks(UserID,FacetValueID,Frequency) VALUES($userID, $facetValueID, 1)";
  $result = mysqli_query($con,$sql);
  if (!$result)
    {
    die('Error: ' . mysqli_error($con));
    }
}


echo "OK";
mysqli_close($con);
?>