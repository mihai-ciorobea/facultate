<?php
$con=mysqli_connect("localhost","root","","faceted_search");
// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }


$userID = $_GET[userID];
$automaticPersonalization = $_GET[automaticPersonalization];
$changedOrder = $_GET[changedOrder];

if ( $automaticPersonalization == 1 ) {
	$sql =	"SELECT f.* FROM Facets f LEFT OUTER JOIN  (SELECT * FROM FacetRanks where UserID=$userID) fr ON f.FacetID=fr.FacetID  
  order by IFNULL(fr.Frequency,0) DESC, IFNULL(fr.Rank,0), f.DefaultRank ASC";
}
else if ($changedOrder == 1) {
	$sql =	"SELECT f.* FROM Facets f LEFT OUTER JOIN (SELECT * FROM FacetRanks where UserID=$userID) fr ON f.FacetID=fr.FacetID 
  order by IFNULL(fr.Rank,0), f.DefaultRank";
}
else {
	$sql =	"SELECT f.* FROM Facets f order by DefaultRank";
}

$result = mysqli_query($con,$sql);
if (!$result)
  {
  die('Error: ' . mysqli_error($con));
  }

$facetsArray = array();
$index = 0;
while($row = mysqli_fetch_assoc($result)) {
     $facetsArray[$index] = $row;
     $index++;
}

echo json_encode($facetsArray);

mysqli_close($con);
?>