<?php
$con=mysqli_connect("localhost","root","","faceted_search");
// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }


$userID = $_POST[userID];
$facetID = $_POST[facetID];
$rank = $_POST[rank];

$sql = "UPDATE Users SET ChangedOrder = 1 WHERE UserID = $userID";
$result = mysqli_query($con,$sql);
if (!$result)
  {
  die('Error: ' . mysqli_error($con));
  }  

//insert/uodate facetsRank
$sql = "SELECT 1 FROM FacetRanks WHERE UserID = $userID and FacetID = $facetID";
$result = mysqli_query($con,$sql);
if (!$result)
  {
  die('Error: ' . mysqli_error($con));
  }  


if(mysqli_num_rows($result)) {
  $sql =  "UPDATE FacetRanks SET Rank = $rank WHERE UserID=$userID and FacetID=$facetID";
  $result = mysqli_query($con,$sql);
  if (!$result)
    {
    die('Error: ' . mysqli_error($con));
    }
}
else {
  $sql =  "INSERT INTO FacetRanks(UserID,FacetID,Rank,Frequency) VALUES($userID, $facetID, $rank, 0)";
  $result = mysqli_query($con,$sql);
  if (!$result)
    {
    die('Error: ' . mysqli_error($con));
    }
}



mysqli_close($con);
?>