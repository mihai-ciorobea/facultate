<?php
$con=mysqli_connect("localhost","root","","faceted_search");
// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }


$userID = $_GET[userID];

$sql =  "SELECT * FROM Users WHERE UserID = $userID";

$result = mysqli_query($con,$sql);
if (!$result)
  {
  die('Error: ' . mysqli_error($con));
  }

$row = mysqli_fetch_assoc($result);

echo json_encode($row);

mysqli_close($con);
?>