<?php
$con=mysqli_connect("localhost","root","","faceted_search");
// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }


$username = $_POST[username];
$password = $_POST[password];
$name = $_POST[name];
$address = $_POST[address];
$sex = $_POST[sex];


	$sql = "SELECT * FROM Users WHERE Username = '$username'";
	$result = mysqli_query($con,$sql);
	if (!$result)
	  {
	  die('Error: ' . mysqli_error($con));
	  }  


	if(mysqli_num_rows($result)) {
 		header('HTTP/1.1 401 Unauthorized', true, 401);
	}
	else {

		$sql = "INSERT INTO Users (Username, Password, Name, Address, Sex) 
				VALUES('$username', '$password', '$name', '$address', $sex)";
		$result = mysqli_query($con,$sql);
		if (!$result)
		  {
		  die('Error: ' . mysqli_error($con));
		  }


		$sql = "SELECT UserID FROM Users WHERE Username = '$username'";
		$result = mysqli_query($con,$sql);
		if (!$result)
		  {
		  die('Error: ' . mysqli_error($con));
		  }
		$row = mysqli_fetch_assoc($result);

		header('HTTP/1.1 200 OK', true, 200);
		echo json_encode($row);
	}

mysqli_close($con);
?>