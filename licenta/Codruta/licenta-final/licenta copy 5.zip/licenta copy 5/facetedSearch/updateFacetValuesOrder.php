<?php
$con=mysqli_connect("localhost","root","","faceted_search");
// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }


$userID = $_POST[userID];
$facetID = $_POST[facetID];
$facetValueID = $_POST[facetValueID];
$rank = $_POST[rank];

$sql = "UPDATE Users SET ChangedOrder = 1 WHERE UserID = $userID";
$result = mysqli_query($con,$sql);
if (!$result)
  {
  die('Error: ' . mysqli_error($con));
  }  

//insert/update facetsRank
$sql = "SELECT 1 FROM FacetValueRanks WHERE UserID = $userID and FacetValueID = $facetValueID";
$result = mysqli_query($con,$sql);
if (!$result)
  {
  die('Error: ' . mysqli_error($con));
  }  


if(mysqli_num_rows($result)) {
  $sql =  "UPDATE FacetValueRanks SET Rank = $rank WHERE UserID=$userID and FacetValueID=$facetValueID";
  $result = mysqli_query($con,$sql);
  if (!$result)
    {
    die('Error: ' . mysqli_error($con));
    }
}
else {
  $sql =  "INSERT INTO FacetValueRanks(UserID,FacetValueID,Rank,Frequency) VALUES($userID, $facetValueID, $rank, 0)";
  $result = mysqli_query($con,$sql);
  if (!$result)
    {
    die('Error: ' . mysqli_error($con));
    }
}



mysqli_close($con);
?>