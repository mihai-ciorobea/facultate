<?php
$con=mysqli_connect("localhost","root","","faceted_search");
// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }

$productID = $_POST[productID];

$sql =  "SELECT BitVector FROM Products WHERE ProductID = $productID";

$result = mysqli_query($con,$sql);
if (!$result)
  {
  die('Error: ' . mysqli_error($con));
  }
$row = mysqli_fetch_assoc($result);

$bitVector = $row[BitVector];


$index = 0;
while ($bitVector != 0) {

  if ( ( $bitVector & 1 ) == 1 ) {

      $sql =  "SELECT BitVector FROM FacetValues WHERE FacetValueID = $index";
      
      $result = mysqli_query($con,$sql);
      if (!$result)
        {
        die('Error: ' . mysqli_error($con));
        }
      $row = mysqli_fetch_assoc($result);
      $facetValueBitVector = $row[BitVector];
      $sql =  "UPDATE FacetValues SET BitVector = $facetValueBitVector - pow(2,$productID) WHERE FacetValueID = $index";
      
      if (!mysqli_query($con,$sql))
        {
        die('Error: ' . mysqli_error($con));
        }
    }

  $index++; 
  $bitVector = $bitVector >> 1;
  
}

$sql =	"DELETE FROM Products WHERE ProductID = $productID";

$result = mysqli_query($con,$sql);
if (!$result)
  {
  die('Error: ' . mysqli_error($con));
  }

echo 'OK';

mysqli_close($con);
?>