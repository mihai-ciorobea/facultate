<?php
$con=mysqli_connect("localhost","root","","faceted_search");
// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }


$facetName = $_POST[facetName];  

$sql =  "SELECT max(DefaultRank) rank FROM Facets";
$result = mysqli_query($con,$sql);
if (!$result)
  {
  die('Error: ' . mysqli_error($con));
  }

$row = mysqli_fetch_assoc($result);
$rank = $row[rank] + 1;  


$sql =	"INSERT INTO Facets (Name, DefaultRank)
		VALUES
		('$facetName', $rank)";

if (!mysqli_query($con,$sql))
  {
  die('Error: ' . mysqli_error($con));
  }
  

$sql =	"SELECT FacetID FROM Facets 
		WHERE Name like '$facetName'";
	
$result = mysqli_query($con,$sql);
if (!$result)
  {
  die('Error: ' . mysqli_error($con));
  }

$row = mysqli_fetch_assoc($result);

echo $row['FacetID'];

mysqli_close($con);
?>