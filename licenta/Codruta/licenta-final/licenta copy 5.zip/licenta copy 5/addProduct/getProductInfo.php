<?php
$con=mysqli_connect("localhost","root","","faceted_search");
// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }

$productID = $_GET[productID];

$sql =	"SELECT * FROM Products WHERE ProductID = $productID";
$result = mysqli_query($con,$sql);
if (!$result)
  {
  die('Error: ' . mysqli_error($con));
  }

$row = mysqli_fetch_assoc($result);
$productInfo = array();

$productInfo["Name"] = $row["Name"];
$productInfo["Price"] = $row["Price"];
$productInfo["Quantity"] = $row["Quantity"];
$productInfo["Description"] = $row["Description"];
$productInfo["Picture"] = $row["Picture"];
$productInfo["FacetValues"] = array();
$productInfo["FacetIDs"] = array();


$bitVector = $row["BitVector"];
$facetValuesArray = array();

$index = 0;
while ( $bitVector != 0 ) {

	if ( ($bitVector & 1) == 1 ) {
		array_push($facetValuesArray, $index);
	}
	$bitVector = $bitVector >> 1;
	$index++;
}

foreach ($facetValuesArray as &$facetValue) {

	$sql =	"SELECT Name, FacetID FROM FacetValues WHERE FacetValueID = $facetValue";
	$result = mysqli_query($con,$sql);
	if (!$result)
	  {
	  die('Error: ' . mysqli_error($con));
	  }

	$row = mysqli_fetch_assoc($result);
	$facetValueName = $row["Name"];
	$facetID = $row["FacetID"];

	if (!array_key_exists($facetID, $productInfo["FacetIDs"])) {

		$sql =	"SELECT Name FROM Facets WHERE FacetID = $facetID";
		$result = mysqli_query($con,$sql);
		if (!$result)
		  {
		  die('Error: ' . mysqli_error($con));
		  }

		$row = mysqli_fetch_assoc($result);
		$productInfo["FacetIDs"][$facetID] = $row["Name"];
		$productInfo["FacetValues"][$facetID] = array();
	}

	$productInfo["FacetValues"][$facetID][$facetValue] = $facetValueName;

}


echo json_encode($productInfo);


mysqli_close($con);
?>