<?php

$con=mysqli_connect("localhost","root","","faceted_search");
// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }

$facetName = $_POST[facetName];  
$defaultRank = $_POST[defaultRank];  

$sql =	"INSERT INTO Facets (Name, DefaultRank)
		VALUES
		('$facetName', '$defaultRank')";

if (!mysqli_query($con,$sql))
  {
  die('Error: ' . mysqli_error($con));
  }
  

$sql =	"SELECT FacetID FROM Facets 
		WHERE Name like '$facetName' AND DefaultRank = '$defaultRank'";
	
$result = mysqli_query($con,$sql);
if (!$result)
  {
  die('Error: ' . mysqli_error($con));
  }

$row = mysqli_fetch_assoc($result);

echo $row['FacetID'];

mysqli_close($con);

?>