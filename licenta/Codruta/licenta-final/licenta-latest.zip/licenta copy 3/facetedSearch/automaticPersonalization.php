<?php
$con=mysqli_connect("localhost","root","","faceted_search");
// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }


$userID = $_GET[userID];
$automaticPersonalization = $_GET[automaticPersonalization];


$sql =	"UPDATE Users SET AutomaticPersonalization=$automaticPersonalization WHERE UserID=$userID";
$result = mysqli_query($con,$sql);
if (!$result)
  {
  die('Error: ' . mysqli_error($con));
  }

echo "OK";
mysqli_close($con);
?>