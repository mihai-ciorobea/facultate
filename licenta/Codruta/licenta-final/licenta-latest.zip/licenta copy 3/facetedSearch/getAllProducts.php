<?php
$con=mysqli_connect("localhost","root","","faceted_search");
// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }


$userID = $_GET[userID];

$weight1 = 0.2;
$weight2 = 0.5;
$weight3 = 0.3;
$weight4 = 0.3;


$sql =  "SELECT p.*, IFNULL(prank.Rank,0) UserRank FROM Products p
            LEFT OUTER JOIN ProductRanks prank ON p.ProductID = prank.ProductID
            LEFT OUTER JOIN 
              ( SELECT sum(IFNULL(Relevance, 0)) relevance, ProductID FROM ProductRelevance
               WHERE UserID = $userID GROUP BY UserID) prel ON p.ProductID = prel.ProductID    
            ORDER BY $weight1 * p.Rank + $weight2 * IFNULL(prank.Rank, 0) + $weight3 * prel.relevance + $weight4 * IFNULL(prank.Frequency, 0)  DESC";


$result = mysqli_query($con,$sql);
if (!$result)
  {
  die('Error: ' . mysqli_error($con));
  }

$productsArray = array();
$index = 0;
while($row = mysqli_fetch_assoc($result)) {
     $productsArray[$index] = $row;
     $index++;
}

echo json_encode($productsArray);

mysqli_close($con);
?>