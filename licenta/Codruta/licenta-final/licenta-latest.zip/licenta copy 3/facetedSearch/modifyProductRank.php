<?php
$con=mysqli_connect("localhost","root","","faceted_search");
// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }


$userID = $_POST[userID];
$productID = $_POST[productID];
$rank = $_POST[rank];



	$sql = "SELECT Rank FROM ProductRanks WHERE UserID = $userID and ProductID = $productID";
	$result = mysqli_query($con,$sql);
	if (!$result)
	  {
	  die('Error: ' . mysqli_error($con));
	  }  


	if(mysqli_num_rows($result)) {

		$row = 	 mysqli_fetch_assoc($result);
		$oldRank = $row[Rank];
		$sql =  "UPDATE ProductRanks SET Rank = $rank WHERE UserID=$userID and ProductID=$productID";
		$result = mysqli_query($con,$sql);
		  if (!$result)
		    {
		    die('Error: ' . mysqli_error($con));
		    }


		$sql = "SELECT Rank, NrVotingUsers FROM Products WHERE ProductID = $productID";
		$sql = "UPDATE Products SET Rank = (Rank * NrVotingUsers - $oldRank + $rank) / NrVotingUsers WHERE ProductID = $productID";
		$result = mysqli_query($con,$sql);
		if (!$result)
		  {
		  die('Error: ' . mysqli_error($con));
		  }  

	}
	else {
		$sql =  "INSERT INTO ProductRanks(UserID,ProductID,Rank,Frequency) VALUES($userID, $productID, $rank, 0)";
		$result = mysqli_query($con,$sql);
		if (!$result)
		  {
		  die('Error: ' . mysqli_error($con));
		  }

		$sql = "SELECT Rank, NrVotingUsers FROM Products WHERE ProductID = $productID";
		$sql = "UPDATE Products SET Rank = (Rank * NrVotingUsers + $rank) / (NrVotingUsers + 1), NrVotingUsers = NrVotingUsers + 1 WHERE ProductID = $productID";
		$result = mysqli_query($con,$sql);
		if (!$result)
		  {
		  die('Error: ' . mysqli_error($con));
		  }    
	}

	
echo 'OK';
mysqli_close($con);
?>