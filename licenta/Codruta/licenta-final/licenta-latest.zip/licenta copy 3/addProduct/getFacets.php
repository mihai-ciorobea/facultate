<?php
$con=mysqli_connect("localhost","root","","faceted_search");
// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }

$sql =	"SELECT * FROM Facets order by Name, DefaultRank";

$result = mysqli_query($con,$sql);
if (!$result)
  {
  die('Error: ' . mysqli_error($con));
  }

$facetsArray = array();
$index = 0;
while($row = mysqli_fetch_assoc($result)) {
     $facetsArray[$index] = $row;
     $index++;
}

echo json_encode($facetsArray);

mysqli_close($con);
?>