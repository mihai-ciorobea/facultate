<?php
$con=mysqli_connect("localhost","root","","faceted_search");
// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }


echo "Upload: " . $_POST[pic] . "<br>";

$productName = $_POST[productName]; 
$productPrice = $_POST[productPrice]; 
$productQuantity = $_POST[productQuantity]; 
$productDescription = $_POST[productDescription]; 
$facetValuesArray = $_POST[facetValuesArray];
$productImg = $_POST[productImage];

$bitVector = 0;

foreach ($facetValuesArray as &$value) {
    $bitVector = $bitVector + (1 << $value);
}

$sql =	"INSERT INTO Products (Name, Description, BitVector, Price, Quantity, Picture)
		VALUES ('$productName', '$productDescription', '$bitVector', '$productPrice', '$productQuantity', '$productImg')";

if (!mysqli_query($con,$sql))
  {
  die('Error: ' . mysqli_error($con));
  }
  
$sql =	"SELECT ProductID FROM Products 
		WHERE Name like '$productName' AND Description like '$productDescription' AND BitVector = $bitVector AND Price = $productPrice AND Quantity = $productQuantity";

$result = mysqli_query($con,$sql);
if (!$result)
  {
  die('Error: ' . mysqli_error($con));
  }
foreach ($facetValuesArray as &$value) {

$row = mysqli_fetch_assoc($result);
$index = $row["ProductID"];


    $sql =	"SELECT BitVector FROM FacetValues
		WHERE FacetValueID = $value";

	$result = mysqli_query($con,$sql);
	if (!$result)
	  {
	  die('Error: ' . mysqli_error($con));
	  }

	$row = mysqli_fetch_assoc($result);
	$bitVector = $row["BitVector"];

	if ((( $bitVector >> $index ) & 1 ) == 0 ) {
		$bitVector = $bitVector + (1 << $index);

printf($bitVector);
		$sql =	"UPDATE FacetValues SET BitVector = $bitVector WHERE FacetValueID = $value";
		
		if (!mysqli_query($con,$sql))
		  {
		  die('Error: ' . mysqli_error($con));
		  }

	}
}

echo "OK";

mysqli_close($con);
?>