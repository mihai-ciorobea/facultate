<?php
$con=mysqli_connect("localhost","root","","faceted_search");
// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }


$facetID = $_POST[facetID];  
$facetValue = $_POST[facetValue];


$sql =  "SELECT max(DefaultRank) rank FROM FacetValues WHERE FacetID='$facetID'";
$result = mysqli_query($con,$sql);
if (!$result)
  {
  die('Error: ' . mysqli_error($con));
  }

$row = mysqli_fetch_assoc($result);
$rank = $row[rank] + 1;  


$sql =	"INSERT INTO FacetValues (Name, FacetID, DefaultRank)
		VALUES
		('$facetValue', '$facetID', '$rank')";

if (!mysqli_query($con,$sql))
  {
  die('Error: ' . mysqli_error($con));
  }
  

$sql =	"SELECT FacetValueID FROM FacetValues
		WHERE Name like '$facetValue' and FacetID like '$facetID'";
	
$result = mysqli_query($con,$sql);
if (!$result)
  {
  die('Error: ' . mysqli_error($con));
  }

$row = mysqli_fetch_assoc($result);

echo $row['FacetValueID'];

mysqli_close($con);
?>