

var userID = 1;//TODO: get this from page params ( after login, this page will be loaded with the userID as param)

//TODO: open one facet => close all others


var showMoreLimit = 5;
var currentBitVector = 0;
var bitVectorMap = new Object();


$( document ).ready(function() {

   	$('#productsList').flexipage({
    	perpage:4,		   
	});

	$('.breadcrumb').chosen();
	$('.search-field').remove();
	$('.chzn-drop').remove();
	$('.breadcrumb').remove();

	loadFacetsAndFacetValues();
	//TODO: decomment this
	//loadAllProducts();

});


function loadFacetsAndFacetValues() {

		$.ajax({
        type: "get",
        url: "getFacets.php",
        dataType : 'text/html',
        
        statusCode: {
		    200: function(data) {
		    		
		    		var facetArray = JSON.parse(data.responseText);
					$(facetArray).each(function( index, element ) {
						addFacetHtml(element.FacetID, element.Name);
						loadFacetValues(element.FacetID);						
					});

					if ( facetArray.length > showMoreLimit ) {

						$("#facetsList").parent().append('<a class="showmore last" onclick="myShow('+"$('#facetsList')"+')">show more...</a>');
						$("#facetsList").parent().append('<a class="hidemore last" onclick="myHide('+"$('#facetsList')"+')">show less...</a>');
						myHide($('#facetsList'));
						
					}
			    }
			  }             
   		});
}

function myHide(parentElement) {

	$(parentElement).children().hide();
	$(parentElement).children().slice(0,showMoreLimit).show();
	$(parentElement).parent().children('.showmore').show();
	$(parentElement).parent().children('.hidemore').hide();
	
}

function myShow(parentElement) {
	
	$(parentElement).children().show();
	$(parentElement).parent().children('.showmore').hide();
	$(parentElement).parent().children('.hidemore').show();
	
}

function loadFacetValues(facetID) {

	$.ajax({
        type: "get",
        url: "getFacetValues.php?facetID="+facetID,
        dataType : 'text/html',
        
        statusCode: {
		    200: function(data) {
		    		
		    		var facetValuesArray = JSON.parse(data.responseText);
		    		facetValuesArray.reverse();
					$(facetValuesArray).each(function( index, element ) {

						bitVectorMap[element.FacetValueID] = element.BitVector;		
						var numberOfProducts = 0;
						if ( currentBitVector != 0 ) {
							numberOfProducts = getNumberOfProducts(element.BitVector & currentBitVector);
						}
						else {
							numberOfProducts = getNumberOfProducts(element.BitVector);
						}
						addFacetValueHtml(facetID, element.FacetValueID, element.Name, numberOfProducts);	
						
					});	

					if ( facetValuesArray.length > showMoreLimit ) {

						$("#f"+facetID+" ul").eq(0).append('<a class="showmore" onclick="myShow('+"$('#f"+facetID+" ul').eq(1)"+')">show more...</a>');
						$("#f"+facetID+" ul").eq(0).append('<a class="hidemore" onclick="myHide('+"$('#f"+facetID+" ul').eq(1)"+')">show less...</a>');
						myHide($("#f"+facetID+" ul").eq(1));
						
					}
					
					updateFacetValues();
			    }
			  }             
   		});
}

function addFacetHtml(facetID, facetName) {

	$("#facetsList").append(
						'<li id=f'+facetID+'>\
                            <a class="facetName">\
                                <img src="images/closed.jpeg">\
                                <img class="hide" src="images/opened.jpeg">\
                                <span class="inline"><span class="facet">'+facetName+'</span></span>\
                            </a>\
                            <ul>\
	                        <ul class="sublist">\
	                        </ul>\
	                        </ul>\
                        </li>');

	setFacetEvents("#f"+facetID);

}

function addFacetValueHtml(facetID, facetValueID, facetValueName, numberOfProducts) {

	$($("#f"+facetID+" ul")[1]).prepend(
							'<li id=fv'+facetValueID+'>\
                                <input class="checkbox" type="checkbox" onclick="">\
                                <span class="inline"><span class="facetValue">'+facetValueName+'</span></span>\
                                <span class="number">('+numberOfProducts+')</span>\
                            </li>');

	setFacetValueEvents("#fv"+facetValueID);
}

function setFacetEvents(liFacetID) {

	$(liFacetID+' ul').hide();
   	$(liFacetID + ' .facetName').click(function() {
		$(this).parent().find('ul').toggle();
		
		var imgs = $(this).parent().find('img');
		var hide = 1;
		if ( $(imgs[0]).hasClass("hide") )
			hide = 0;

		$(imgs[hide]).removeClass("hide");
		$(imgs[1-hide]).addClass("hide");

	});
}

function setFacetValueEvents(liFacetValueID) {

	$(liFacetValueID).click(function() {

		var checkbox = $(this).find('input');
        var checked = checkbox.is(":checked");
        checkbox.prop("checked", !checked);

		var liFacetValueID = '#'+$(this).attr('id');
		modifyRestriction(liFacetValueID, !checked);
	});

	$(liFacetValueID).find('input').click(function () {

		var checked = $(this).is(":checked");
        $(this).prop("checked", !checked);

	});

}


function modifyRestriction(liFacetValueID, isChecked) {

	var facetValueID = liFacetValueID.substring(3);

	if ( isChecked ) {

		var facetValueName = $(liFacetValueID + ' .facetValue').text();
		$('ul.chzn-choices').append('<li id=chosen'+facetValueID+' class="search-choice"><span>'+facetValueName+'</span>\
									 <a href="#" class="search-choice-close" rel="0" onclick="removeChosenRestriction('+facetValueID+')"></a></li>');
		$('ul.chzn-choices').scrollTop($('ul.chzn-choices')[0].scrollHeight);

	}
	else {
		$('#chosen'+facetValueID).remove();
	}

	updateResultsList(facetValueID, isChecked);
}

function removeChosenRestriction(facetValueID) {

	$('#fv'+facetValueID).click();
	$('#chosen'+facetValueID).remove();
}

function updateResultsList(facetValueID, isChecked) {

	if ( isChecked ) {

		if ( currentBitVector == 0 )
			currentBitVector = bitVectorMap[facetValueID];
		else {
			currentBitVector = currentBitVector & bitVectorMap[facetValueID];
		}
	}
	else {

		currentBitVector = 0;
		$('.sublist').each(function(index, element){
			$(element).find('li').each(function(ind, elem) {
				if ( $(elem).find('input').is(":checked") ) {
					
					var facetValueID = $(elem).attr('id').substring(2);

					if ( currentBitVector == 0 ) {						
						currentBitVector = bitVectorMap[facetValueID];
					}
					else {
						currentBitVector = currentBitVector & bitVectorMap[facetValueID];
					}
				}

			});			
		});
	}

	updateFacetValues();
	updateResults();

}

function updateFacetValues() {

/*
	$('.sublist').each(function(index, element){
		$(element).find('li').each(function(ind, elem) {
				
			var facetValueID = $(elem).attr('id').substring(2);
			var bitVector = bitVectorMap[facetValueID];
			if ( currentBitVector != 0 )
				bitVector = bitVector & currentBitVector;
			var numberOfProducts = getNumberOfProducts(bitVector);

			if ( numberOfProducts == 0 )
				$(elem).hide();
			else {
				$(elem).find('.number').text('('+numberOfProducts+')');
				$(elem).show();
			}
		});		

		setTimeout(function(){
			var size = 0;
			$(element).children().each(function(ind, elem) {
				if ( $(elem).is(':visible') )
					size++;
			});
			if ( size == 0 ) {
				$(element).parent().hide();
			}
			else {
				$(element).parent().show();
				if ( size <= showMoreLimit ) {
					$(element).parent().find('.showmore').hide();
					$(element).parent().find('.hidemore').hide();
				}
			}
		},1000);
		
	});

*/

//TODO: hide the facet values with count 0 (update showmore and hidemore too)
}

function updateResults() {

	//TODO
	var productIDsArray = [];
	var i;
	var bitVector = currentBitVector;
	for ( i = 0; bitVector != 0; i++ ) {
		var set = bitVector & 1;
		bitVector = bitVector >>> 1;
		if ( set )
			productIDsArray.push(i);
	}

	loadProducts(productIDsArray);

}

function getNumberOfProducts(bitVector) {

	var i;
    for ( i = 0; bitVector > 0; i++) {
        bitVector &= bitVector - 1;
    }
    return i;

}

function loadProducts(productIDsArray) {

	$('#productsList').children().each(function(index, element) {
		$(element).remove();
	});

		$.ajax({
        type: "POST",
        url: "getProducts.php",
        data: {productsArray : productIDsArray},
        dataType : 'text/html',
        
        statusCode: {
		    200: function(data) {
		    		
		    		var productsArray = JSON.parse(data.responseText);
		    		$('#nrResults').text(productsArray.length);
					$(productsArray).each(function( index, element ) {						
						addProductHtml(element);											
					});

			    }
			  }             
   		});
}

function loadAllProducts() {

	$('#productsList').children().each(function(index, element) {
		$(element).remove();
	});

	$.ajax({
        type: "get",
        url: "getAllProducts.php",
        dataType : 'text/html',
        
        statusCode: {
		    200: function(data) {
		    		
		    		var productsArray = JSON.parse(data.responseText);
		    		$('#nrResults').text(productsArray.length);
					$(productsArray).each(function( index, element ) {						
						addProductHtml(element);
					});

			    }
			  }             
   		});

}

function addProductHtml(element) {

	//TODO: ADD PICTURE NAME

	$('#productsList').append('<li id=p'+element.ProductID+'>\
			                        <table>\
			                            <tr>\
			                                <td rowspan="3" class="productImage">\
			                                    <img class="productPicture" src="images/default.jpg">\
			                                </td>\
			                                <td class="productName">'+element.Name+'</td>\
			                            </tr>\
			                            <tr>\
			                                <td class="productPrice">'+element.Price+'$</td>\
			                                <td class="buttons">\
			                                    <img src="images/edit.png" onclick="editProduct('+element.ProductID+')">\
			                                    <img src="images/remove.png" onclick="removeProduct('+element.ProductID+')">\
			                                </td>\
			                            </tr>\
			                            <tr>\
			                                <td colspan="2">\
			                                    <p class="productDescription">'+element.Description+'</p>\
			                                </td>\
			                            </tr>\
			                        </table>\
			                    </li>');

}

function editProduct(productID) {
	window.location.href = "../addProduct/index.html?productId="+productID;
}

function removeProduct(productID) {

	$('#p'+productID).remove();
	$('#nrResults').text($('#nrResults').text() - 1);
}



