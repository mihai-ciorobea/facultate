<?php
$con=mysqli_connect("localhost","root","","faceted_search");
// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }


$productIDs = $_POST[productsArray];


if ( count($productIDs) == 0)
  return;

$list = "(";
foreach ($productIDs as &$value) {
    $list = $list . $value . ',';
}
$list = substr($list, 0, strlen($list) - 1 );
$list = $list . ")";


$sql =	"SELECT * FROM Products WHERE ProductID in $list order by Rank";

$result = mysqli_query($con,$sql);
if (!$result)
  {
  die('Error: ' . mysqli_error($con));
  }

$productsArray = array();
$index = 0;
while($row = mysqli_fetch_assoc($result)) {
     $productsArray[$index] = $row;
     $index++;
}

echo json_encode($productsArray);

mysqli_close($con);
?>