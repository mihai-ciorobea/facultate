<?php
$con=mysqli_connect("localhost","root","Visine#3","FacetedSearch");
// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }

$sql =	"SELECT ProductID, Name, Description, Price, Quantity FROM Products";

$result = mysqli_query($con,$sql);
if (!$result)
  {
  die('Error: ' . mysqli_error($con));
  }

$productsArray = array();
$index = 0;
while($row = mysqli_fetch_assoc($result)) {
     $productsArray[$index] = $row;
     $index++;
}

echo json_encode($productsArray);

mysqli_close($con);
?>