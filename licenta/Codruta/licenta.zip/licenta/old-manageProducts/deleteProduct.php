<?php
$con=mysqli_connect("localhost","root","Visine#3","FacetedSearch");
// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }


$productID = $_POST[productID];

$sql =	"DELETE FROM Products WHERE ProductID = $productID";

if (!mysqli_query($con,$sql))
  {
  die('Error: ' . mysqli_error($con));
  }
  
echo "OK";

mysqli_close($con);
?>