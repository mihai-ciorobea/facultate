

//TODO: search products by name
//TODO: click on description => popup with the entire description


$(document).ready( function() {

	loadProducts();

});

function loadProducts() {

	$.ajax({
        type: "get",
        url: "getProducts.php?",
        dataType : 'text/html',
        
        statusCode: {
		    200: function(data) {
		    	
		    		var productsArray = JSON.parse(data.responseText);
		    		$(productsArray).each(function( index, element ) {

						$('#items').append(
							'<tr id='+element.ProductID+'>\
								<td class="c1"><div>'+element.Name+'</div></td>\
								<td class="c2"><div>'+element.Description+'</div></td>\
								<td class="c3"><div>'+element.Price+'</div></td>\
								<td class="c4"><div>'+element.Quantity+'</div></td>\
	                         	<td class="c5">\
	                          		<button class="left" type="button" onclick="editProduct('+element.ProductID+')"><img src="images/edit.png"/></button>\
	                          		<button class="right" type="button" onclick="deleteProduct('+element.ProductID+')"><img src="images/delete.png"/></button>\
	                         	</td>\
	                    	</tr>'
	                    );

					});

					alternateItems();
					addListenersForButtons();

			    }
			  }             
   		});
}

function addListenersForButtons() {

	$('#items tr button').each(function(index, element) {
		$(element).hide();
	});


	$('#items tr').each(function(index, element) {
		element.onmouseover = function(){

		 $(element).find('button').each(function(ind, elem) {
		 	$(elem).show();
		 });
		};
	});

	$('#items tr').each(function(index, element) {
		element.onmouseout = function(){

		 $(element).find('button').each(function(ind, elem) {
		 	$(elem).hide();
		 });
		};
	});
}


function editProduct(productID) {

	window.location.href = "../addProduct/addProduct.html?productId="+productID;
}

function deleteProduct(productId) {

	if (confirm("Are you sure you want to delete this item?")) {
    
    	$.ajax({
        type: "post",
        url: "deleteProduct.php?",
        dataType : 'text/html',
        data: { productID : productId },

        statusCode: {
		    200: function(data) {
		    		
		    		$('#items tr#'+productId).remove();
		    		alternateItems();
			    }
			  }             
    });
	
    }

}

function alternateItems() {

	var alt = 0;
	$('#items tr').each (function(index, element) {
		if ( alt == 0 ){
			alt = 1;
			$(element).removeClass("alt");
		}
		else {
			alt = 0;
			$(element).addClass("alt");	
		}
	});
}





