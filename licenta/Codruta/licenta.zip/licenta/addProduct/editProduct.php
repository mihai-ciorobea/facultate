<?php
$con=mysqli_connect("localhost","root","","faceted_search");
// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }


$productID = $_POST[productID]; 
$productName = $_POST[productName]; 
$productPrice = $_POST[productPrice]; 
$productQuantity = $_POST[productQuantity]; 
$productDescription = $_POST[productDescription]; 
$facetValuesArray = $_POST[facetValuesArray]; 


$sql =	"SELECT BitVector FROM Products 
		WHERE ProductID = '$productID'";

$result = mysqli_query($con,$sql);
if (!$result)
  {
  die('Error: ' . mysqli_error($con));
  }

$row = mysqli_fetch_assoc($result);
$oldBitVector = $row["BitVector"];

//update the bitVectors for the old facetValues

$oldFacetValuesArray = array();
$index = 0;
while ( $oldBitVector != 0 ) {

	if ( ($oldBitVector & 1) == 1 ) {
		array_push($oldFacetValuesArray, $index);
	}
	$oldBitVector = $oldBitVector >> 1;
	$index++;
}
foreach ($oldFacetValuesArray as &$value) {

    $sql =	"SELECT BitVector FROM FacetValues
		WHERE FacetValueID = $value";

	$result = mysqli_query($con,$sql);
	if (!$result)
	  {
	  die('Error: ' . mysqli_error($con));
	  }

	$row = mysqli_fetch_assoc($result);
	$bitVector = $row["BitVector"];

	if ((( $bitVector >> $index ) & 1 ) == 1 ) {
		$bitVector = $bitVector - (1 << $index);

		$sql =	"UPDATE FacetValues SET BitVector = $bitVector WHERE FacetValueID = $value";
		
		if (!mysqli_query($con,$sql))
		  {
		  die('Error: ' . mysqli_error($con));
		  }

	}
}


$bitVector = 0;

foreach ($facetValuesArray as &$value) {
    $bitVector = $bitVector + (1 << $value);
}

$sql =	"UPDATE Products SET Name = '$productName', Description = '$productDescription', BitVector = '$bitVector', Price = '$productPrice', Quantity = '$productQuantity'
		WHERE ProductID = '$productID'";

if (!mysqli_query($con,$sql))
  {
  die('Error: ' . mysqli_error($con));
  }
  
 //update the bitVectors for the new facetValues
foreach ($facetValuesArray as &$value) {

    $sql =	"SELECT BitVector FROM FacetValues
		WHERE FacetValueID = $value";

	$result = mysqli_query($con,$sql);
	if (!$result)
	  {
	  die('Error: ' . mysqli_error($con));
	  }

	$row = mysqli_fetch_assoc($result);
	$bitVector = $row["BitVector"];

	if ((( $bitVector >> $index ) & 1 ) == 0 ) {
		$bitVector = $bitVector + (1 << $index);

		$sql =	"UPDATE FacetValues SET BitVector = $bitVector WHERE FacetValueID = $value";
		
		if (!mysqli_query($con,$sql))
		  {
		  die('Error: ' . mysqli_error($con));
		  }

	}
}

echo "OK";

mysqli_close($con);
?>