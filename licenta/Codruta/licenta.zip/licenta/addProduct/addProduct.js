
var edit = false;
var editedProductID;

//TODO: verify that the same value(or empty field) cannot be added to a drop-down/ to the list of facets for product
//TODO: check all fields are completed before submitting
//add remove button for facet
//make remove buttons appera in mouseover only
//use select2
//make add new facet/facet value on enter in the textbox
//remove the done button ?

$( document ).ready(function() {
    
    edit = false;
	var params = location.search; 
    if ( $.trim(params) != "" ) {
    	editProduct(params.substring(11));
    }

    loadFacetsAndFacetValues();

});

function editProduct(productID) {

	edit = true;
	editedProductID = productID;
	$('.title').text("Edit product");

	$.ajax({
        type: "get",
        url: "getProductInfo.php?productID="+productID,
        dataType : 'text/html',
        
        statusCode: {
		    200: function(data) {
		    		
		    		var productInfo = JSON.parse(data.responseText);
		    		
		    		$('#productName').val(productInfo.Name);
		    		$('#productPrice').val(productInfo.Price);
		    		$('#productQuantity').val(productInfo.Quantity);
					$('#productDescription').val(productInfo.Description);
					
					$(Object.keys(productInfo.FacetIDs)).each(function(facetIndex, facetID){

						console.log(facetID);
						console.log(productInfo.FacetIDs[facetID]);

						$(Object.keys(productInfo.FacetValues[facetID])).each(function(facetValueIndex, facetValueID) {

							console.log(facetValueID);
							console.log(productInfo.FacetValues[facetID][facetValueID]);

							addFacetValueHtml(facetID, productInfo.FacetIDs[facetID], facetValueID, productInfo.FacetValues[facetID][facetValueID]);
						});
					});
			    }
		}             
   	});
}

function loadFacetsAndFacetValues() {

		$.ajax({
        type: "get",
        url: "getFacets.php",
        dataType : 'text/html',
        
        statusCode: {
		    200: function(data) {
		    		
		    		var facetArray = JSON.parse(data.responseText);
					$(facetArray).each(function( index, element ) {
						$("#facetsSelect").append($("<option id=f"+element.FacetID+"></option>").text(element.Name));
					});

					$(document).on('change', '#facetsSelect', loadFacetValues);
					loadFacetValues();

			    }
			  }             
   		});
}


function loadFacetValues() {

	if ($('#facetsSelect').find('option:selected').length == 0)
		return;

	var facetID = $('#facetsSelect').find('option:selected').attr('id').substring(1);
	$('#facetValuesSelect option').remove();
   
    $.ajax({
        type: "get",
        url: "getFacetValues.php?facetID="+facetID,
        dataType : 'text/html',
        
        statusCode: {
		    200: function(data) {
		    		
		    		var facetValuesArray = JSON.parse(data.responseText);
					$(facetValuesArray).each(function( index, element ) {
						$("#facetValuesSelect").append($("<option id=fv"+element.FacetValueID+"></option>").text(element.Name));
					});

			    }
			  }             
   		});
}

function addNewFacet(newFacet) {

	//var newFacet = $('#newFacetName').val();
	if ( $.trim(newFacet) == "" )
		return;

	$.ajax({
        type: "post",
        url: "addFacet.php?",
        dataType : 'text/html',
        data: { facetName : newFacet },

        statusCode: {
		    200: function(data) {
		    		
		    		var facetID = data.responseText;
					var select = $("#facetsSelect");
					select.append($("<option id=f"+facetID+" value='"+newFacet+"'></option>").text(newFacet));
					select.val(newFacet).trigger("change");
			    }
			  }             
    });

}

function addNewFacetValue() {

	var selectedFacet = $("#facetsSelect option:selected").val();
	var selectedFacetID = $("#facetsSelect option:selected").attr('id');
	var newFacetValue = $('#newFacetValueName').val();

	if ( $.trim(newFacetValue) == "" )
		return;

	$.ajax({
        type: "post",
        url: "addFacetValue.php?",
        dataType : 'text/html',
        data: { facetID : selectedFacetID.substring(1), facetValue : newFacetValue },

        statusCode: {
		    200: function(data) {
		    		var newFacetValueID = data.responseText;
		    		var select = $("#facetValuesSelect");
					select.append($("<option id=fv"+newFacetValueID+"></option>").text(newFacetValue));
					select.val(newFacetValue).prop({selected: true});
					$('#newFacetValueName').val("");
			    }
			  }            
    });

}

function doneFacetSettings() {

	var selectedFacet = $("#facetsSelect option:selected").val();
	var selectedFacetID = $("#facetsSelect option:selected").attr('id');
	var selectedFacetValue = $("#facetValuesSelect option:selected").val();
	var selectedFacetValueID = $("#facetValuesSelect option:selected").attr('id');

	addFacetValueHtml(selectedFacetID, selectedFacet, selectedFacetValueID, selectedFacetValue);	
}

function addFacetValueHtml(newFacetID, newFacetName, newFacetValueID, newFacetValue) {

	$('#none').hide();

	var facetLi = $('#l'+newFacetID);

	if ( facetLi.length == 0 ) {	
		$('#facetsList').append('<li id=l'+newFacetID+'>'+newFacetName+'<ul></ul></li>');
	}

	var ul = $('#l'+newFacetID+' ul');
	$(ul).append('<li class="facetValues" id=l2'+newFacetValueID+'>'+newFacetValue+' <a href="#" onclick=deleteFacetValueForProduct("'+newFacetValueID+'","'+ newFacetID+'")> <img src="images/remove.png"> </a> </li> ');

}

function deleteFacetValueForProduct(facetValueID, facetID) {

	$('#l2'+facetValueID).remove();
	if ( $('#l'+facetID+' li').length == 0 ) {
		$('#l'+facetID).remove();
	}

	if ( $('[id^="l2"]').length == 0 )
		$('#none').show();
}

//update the database with the new information about the current product
function saveProduct() {

	//TODO: check that the necesarry fields are completed

	var facetValues = [];
	
	$(".facetValues").each(function( index, element ) {
		facetValues.push($(element).attr('id').substring(3));
	});

	var url = "addProduct.php?";
	var data = { productName: $('#productName').val(),
    			productPrice: $('#productPrice').val(),
    			productQuantity: $('#productQuantity').val(),
    			productDescription: $('#productDescription').val(),
    			facetValuesArray: facetValues};
    if ( edit ) {
		url = "updateProduct.php?";
		data[productID] =  editedProductID;
    }

	$.ajax({
        type: "post",
        url: url,
        dataType : 'text/html',
        data: data,

        statusCode: {
		    200: function(data) {
		    		window.location.href = "../manageProducts/manageProducts.html";
			    }
			  }            
    });

}

function cancelProduct() {
	window.location.href = "../manageProducts/manageProducts.html";
}



