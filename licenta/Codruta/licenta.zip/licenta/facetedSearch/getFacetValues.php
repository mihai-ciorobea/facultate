<?php
$con=mysqli_connect("localhost","root","","faceted_search");
// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }


$userID = $_GET[userID];
$facetID = $_GET[facetID];
$automaticPersonalization = $_GET[automaticPersonalization];
$changedOrder = $_GET[changedOrder];


if ( $automaticPersonalization == 1 ) {
	$sql =	"SELECT f.FacetValueID, f.Name, f.BitVector FROM FacetValues f 
          LEFT OUTER JOIN ( SELECT * FROM FacetValueRanks WHERE UserID='$userID') fr ON f.FacetValueID=fr.FacetValueID 
          WHERE f.FacetID='$facetID'
			    ORDER BY IFNULL(fr.Frequency,0), IFNULL(fr.Rank,0), f.DefaultRank";
}
else if ($changedOrder == 1) {
    $sql =  "SELECT f.FacetValueID, f.Name, f.BitVector FROM FacetValues f 
          LEFT OUTER JOIN (SELECT * FROM FacetValueRanks WHERE UserID='$userID') fr ON f.FacetValueID=fr.FacetValueID 
          WHERE f.FacetID='$facetID' 
          ORDER BY IFNULL(fr.Rank,0), f.DefaultRank";
}
else {
	$sql =	"SELECT FacetValueID, Name, BitVector FROM FacetValues where FacetID=$facetID
			order by DefaultRank";
}

$result = mysqli_query($con,$sql);
if (!$result)
  {
  die('Error: ' . mysqli_error($con));
  }

$facetValuesArray = array();
$index = 0;
while($row = mysqli_fetch_assoc($result)) {
     $facetValuesArray[$index] = $row;
     $index++;
}

echo json_encode($facetValuesArray);

mysqli_close($con);
?>