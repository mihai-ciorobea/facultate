

var userID = 1;//TODO: get this from page params ( after login, this page will be loaded with the userID as param)
var automaticPersonalization = 1;//TODO: get this from page params ( after login, this page will be loaded with the userID as param)
var changedOrder = 0;//TODO: get this from page params ( after login, this page will be loaded with the userID as param)

//TODO: every product must be in the tables with different ranks for every user...; the same for facets/facet values=>
//=> use left/right join
//TODO: open one facet => close all others

//TODO: update frequency for products
//TODO: modify order of facets/fv and retain it every time

var showMoreLimit = 5;
var currentBitVector = 0;
var bitVectorMap = new Object();


$( document ).ready(function() {

	if ( automaticPersonalization ) {
		$('.switch').find('li').eq(1).addClass('on');
	}
	else {
		$('.switch').find('li').eq(0).addClass('on');
	}

	$(".switch li").click(function(){
        $(".switch li").removeClass("on");
        $(this).addClass("on"); 
    });

   	$('#productsList').flexipage({
    	perpage:4,		   
	});

	$('.breadcrumb').chosen();
	$('.search-field').remove();
	$('.chzn-drop').remove();
	$('.breadcrumb').remove();

	loadFacetsAndFacetValues();
	loadAllProducts();
});


	





//TODO============== (save the order of the facets every time ...)
$(function() {
    $('#sortable').sortable({
        start: function(event, ui) {
            var start_pos = ui.item.index();
            ui.item.data('start_pos', start_pos);
        },
        change: function(event, ui) {
            var start_pos = ui.item.data('start_pos');
            var index = ui.placeholder.index();
            if (start_pos < index) {
                $('#sortable li:nth-child(' + index + ')').addClass('highlights');
            } else {
                $('#sortable li:eq(' + (index + 1) + ')').addClass('highlights');
            }
        },
        update: function(event, ui) {
            $('#sortable li').removeClass('highlights');
        }
    });
});
//===================






function loadFacetsAndFacetValues() {

		$.ajax({
        type: "get",
        url: "getFacets.php?userID="+userID+"&automaticPersonalization="+automaticPersonalization+"&changedOrder="+changedOrder,
        dataType : 'text/html',
        
        statusCode: {
		    200: function(data) {
		    		
		    		var facetArray = JSON.parse(data.responseText);
					$(facetArray).each(function( index, element ) {
						addFacetHtml(element.FacetID, element.Name);
						loadFacetValues(element.FacetID);						
					});

					if ( facetArray.length > showMoreLimit ) {

						$("#facetsList").parent().append('<a class="showmore last" onclick="myShow('+"$('#facetsList')"+')">show more...</a>');
						$("#facetsList").parent().append('<a class="hidemore last" onclick="myHide('+"$('#facetsList')"+')">show less...</a>');
						myHide($('#facetsList'));
						
					}
			    }
			  }             
   		});
}

function myHide(parentElement) {

	$(parentElement).children().hide();
	$(parentElement).children().slice(0,showMoreLimit).show();
	$(parentElement).parent().children('.showmore').show();
	$(parentElement).parent().children('.hidemore').hide();
	
}

function myShow(parentElement) {
	
	$(parentElement).children().show();
	$(parentElement).parent().children('.showmore').hide();
	$(parentElement).parent().children('.hidemore').show();
	
}

function loadFacetValues(facetID) {

	$.ajax({
        type: "get",
        url: "getFacetValues.php?facetID="+facetID+"&userID="+userID+"&automaticPersonalization="+automaticPersonalization+"&changedOrder="+changedOrder,
        dataType : 'text/html',
        
        statusCode: {
		    200: function(data) {
		    		
		    		var facetValuesArray = JSON.parse(data.responseText);
		    		facetValuesArray.reverse();
					$(facetValuesArray).each(function( index, element ) {

						bitVectorMap[element.FacetValueID] = element.BitVector;		
						var numberOfProducts = getNumberOfProducts(element.BitVector);
						if ( currentBitVector != 0 ) {
							numberOfProducts = getNumberOfProducts(element.BitVector & currentBitVector);
						}
						addFacetValueHtml(facetID, element.FacetValueID, element.Name, numberOfProducts);	
						
					});	

					if ( facetValuesArray.length > showMoreLimit ) {

						$("#f"+facetID+" ul").eq(0).append('<a class="showmore" onclick="myShow('+"$('#f"+facetID+" ul').eq(1)"+')">show more...</a>');
						$("#f"+facetID+" ul").eq(0).append('<a class="hidemore" onclick="myHide('+"$('#f"+facetID+" ul').eq(1)"+')">show less...</a>');
						myHide($("#f"+facetID+" ul").eq(1));
						
					}
					
					updateFacetValues();
			    }
			  }             
   		});
}

function addFacetHtml(facetID, facetName) {

	$("#facetsList").append(
						'<li id=f'+facetID+'>\
                            <a class="facetName">\
                                <img src="images/closed.jpeg">\
                                <img class="hide" src="images/opened.jpeg">\
                                <span class="inline"><span class="facet">'+facetName+'</span></span>\
                            </a>\
                            <ul>\
	                        <ul class="sublist">\
	                        </ul>\
	                        </ul>\
                        </li>');

	setFacetEvents("#f"+facetID);

}

function addFacetValueHtml(facetID, facetValueID, facetValueName, numberOfProducts) {

	$($("#f"+facetID+" ul")[1]).prepend(
							'<li id=fv'+facetValueID+'>\
                                <input class="checkbox" type="checkbox" onclick="">\
                                <span class="inline"><span class="facetValue">'+facetValueName+'</span></span>\
                                <span class="number">('+numberOfProducts+')</span>\
                            </li>');

	setFacetValueEvents("#fv"+facetValueID);
}

function setFacetEvents(liFacetID) {

	$(liFacetID).find('a').mouseover(function() {
 		$('#facetsList').sortable();
	});
	$('.sortable').sortable({
    	items: ':not(.showmore)'
	});
	
	$(liFacetID+' ul').hide();
   	$(liFacetID + ' .facetName').click(function() {
		$(this).parent().find('ul').toggle();
		
		var imgs = $(this).parent().find('img');
		var hide = 1;
		if ( $(imgs[0]).hasClass("hide") )
			hide = 0;

		$(imgs[hide]).removeClass("hide");
		$(imgs[1-hide]).addClass("hide");

	});
}

function setFacetValueEvents(liFacetValueID) {

	$(liFacetValueID).mouseover(function() {
		$('#facetsList').sortable('destroy');
	});
	$(liFacetValueID).parent().sortable();

	$(liFacetValueID).click(function() {

		var checkbox = $(this).find('input');
        var checked = checkbox.is(":checked");
        checkbox.prop("checked", !checked);

		var liFacetValueID = '#'+$(this).attr('id');
		modifyRestriction(liFacetValueID, !checked);
	});

	$(liFacetValueID).find('input').click(function () {

		var checked = $(this).is(":checked");
        $(this).prop("checked", !checked);

	});

}



function modifyRestriction(liFacetValueID, isChecked) {

	var facetValueID = liFacetValueID.substring(3);

	if ( isChecked ) {

		var facetValueName = $(liFacetValueID + ' .facetValue').text();
		$('ul.chzn-choices').append('<li id=chosen'+facetValueID+' class="search-choice"><span>'+facetValueName+'</span>\
									 <a href="#" class="search-choice-close" rel="0" onclick="removeChosenRestriction('+facetValueID+')"></a></li>');
		$('ul.chzn-choices').scrollTop($('ul.chzn-choices')[0].scrollHeight);

	}
	else {
		$('#chosen'+facetValueID).remove();
	}

	//update the frequency of clicks on the current facet and facet value
	if ( isChecked ) {
		incrementFrequency(facetValueID);
	}

	updateResultsList(facetValueID, isChecked);
}

function removeChosenRestriction(facetValueID) {

	$('#fv'+facetValueID).click();
	$('#chosen'+facetValueID).remove();
}

function incrementFrequency(facetValueID) {

	var facetID = $('#fv'+facetValueID).parent().parent().parent().attr('id').substring(1);

	$.ajax({
        type: "get",
        url: "incrementFrequency.php?userID="+userID+"&facetID="+facetID+"&facetValueID="+facetValueID,
        dataType : 'text/html'
   		});

}

function changeAutomaticPersonalization(automatic) {

	automaticPersonalization = automatic;
	$.ajax({
        type: "get",
        url: "automaticPersonalization.php?userID="+userID+"&automaticPersonalization="+automatic,
        dataType : 'text/html'
   		});
}

function updateResultsList(facetValueID, isChecked) {

	if ( isChecked ) {

		if ( currentBitVector == 0 )
			currentBitVector = bitVectorMap[facetValueID];
		else {
			currentBitVector = currentBitVector & bitVectorMap[facetValueID];
		}
	}
	else {

		currentBitVector = 0;
		$('.sublist').each(function(index, element){
			$(element).find('li').each(function(ind, elem) {
				if ( $(elem).find('input').is(":checked") ) {
					
					var facetValueID = $(elem).attr('id').substring(2);

					if ( currentBitVector == 0 ) {						
						currentBitVector = bitVectorMap[facetValueID];
					}
					else {
						currentBitVector = currentBitVector & bitVectorMap[facetValueID];
					}
				}

			});			
		});
	}

	updateFacetValues();
	updateResults();

}

function updateFacetValues() {

/*
	$('.sublist').each(function(index, element){
		$(element).find('li').each(function(ind, elem) {
				
			var facetValueID = $(elem).attr('id').substring(2);
			var bitVector = bitVectorMap[facetValueID];
			if ( currentBitVector != 0 )
				bitVector = bitVector & currentBitVector;
			var numberOfProducts = getNumberOfProducts(bitVector);

			if ( numberOfProducts == 0 )
				$(elem).hide();
			else {
				$(elem).find('.number').text('('+numberOfProducts+')');
				$(elem).show();
			}
		});		

		setTimeout(function(){
			var size = 0;
			$(element).children().each(function(ind, elem) {
				if ( $(elem).is(':visible') )
					size++;
			});
			if ( size == 0 ) {
				$(element).parent().hide();
			}
			else {
				$(element).parent().show();
				if ( size <= showMoreLimit ) {
					$(element).parent().find('.showmore').hide();
					$(element).parent().find('.hidemore').hide();
				}
			}
		},1000);
		
	});

*/

//TODO: hide the facet values with count 0 (update showmore and hidemore too)
}

function updateResults() {

	//TODO
	var productIDsArray = [];
	var i;
	var bitVector = currentBitVector;
	for ( i = 0; bitVector != 0; i++ ) {
		var set = bitVector & 1;
		bitVector = bitVector >>> 1;
		if ( set )
			productIDsArray.push(i);
	}

	loadProducts(productIDsArray);

}

function getNumberOfProducts(bitVector) {

	var i;
    for ( i = 0; bitVector > 0; i++) {
        bitVector &= bitVector - 1;
    }
    return i;

}

function getCurrentRestrictions() {

	var restrictionsIDsArray = [];
	$('.chzn-choices').find('li').each(function(index, element) {

		restrictionsIDsArray.push($(element).attr('id').substring(6));
	});

	return restrictionsIDsArray;
}

function loadProducts(productIDsArray) {

	$('#productsList').children().each(function(index, element) {
		$(element).remove();
	});

	$.ajax({
    type: "POST",
    url: "getProducts.php",
    data: { userID : userID,
    		productIDsArray : productIDsArray,
    		restrictionsIDsArray : getCurrentRestrictions() },
    dataType : 'text/html',
    
    statusCode: {
	    200: function(data) {
	    		
	    		var productsArray = JSON.parse(data.responseText);
	    		$('#nrResults').text(productsArray.length);
				$(productsArray).each(function( index, element ) {
					addProductHtml(element);
				});

		    }
		  }             
		});

}

function loadAllProducts() {
/*
	$('#productsList').children().each(function(index, element) {
		$(element).remove();
	});
*/		
	$.ajax({
    type: "get",
    url: "getAllProducts.php?userID="+userID,
    dataType : 'text/html',
    
    statusCode: {
	    200: function(data) {
	    		
	    		var productsArray = JSON.parse(data.responseText);
	    		$('#nrResults').text(productsArray.length);
				$(productsArray).each(function( index, element ) {
					addProductHtml(element);
				});

		    }
		  }             
		});

}

function addProductHtml(element) {

	//TODO: ADD PICTURE NAME

	$('#productsList').append('<li>\
							        <table>\
							            <tr>\
							                <td rowspan="3" class="productImage">\
							                    <img class="productPicture" src="images/default.jpeg">\
							                </td>\
							                <td class="productName">'+element.Name+'</td>\
							                <td class="productPrice">'+element.Price+'$</td>\
							            </tr>\
							            <tr>\
											<td class="rateId">\
			                                    <input type="range" min="0" max="7" value="3" step="0.5" id=backing'+element.ProductID+'>\
			                                    <div class="rateit" data-rateit-backingfld=#backing'+element.ProductID+'>\
				                                </div>\
			                                </td>\
							                <td class="wasRelevant">\
							                    Was this relevant? <a href="" onclick="modifyRelevance('+element.ProductID+', true)">Yes</a>\
							                     / <a href="" onclick="modifyRelevance('+element.ProductID+', false)">No</a>\
							                </td>\
							            </tr>\
							            <tr>\
							                <td colspan="2">\
							                    <p class="productDescription">'+element.Description+'</p>\
							                </td>\
							            </tr>\
							        </table>\
							    </li>');



	$('div.rateit').rateit();
  

}

function modifyRelevance(prodcutID, increase) {

	$.ajax({
        type: "POST",
        url: "modifyRelevance.php",
        data: { userID : userID,
        		productID : productID,
        		restrictionsIDsArray : getCurrentRestrictions(),
        		increase : increase },
        dataType : 'text/html',
    });

}



