<?php
$con=mysqli_connect("localhost","root","","faceted_search");
// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }


$userID = $_POST[userID];
$productID = $_POST[productID]
$restrictionsIDsArray = $_POST[restrictionsIDsArray];
$increase = $_POST[increase];

if(count($restrictionsIDsArray) == 0)
	return;

foreach ($restrictionsIDsArray as &$value) {

	$sql = "SELECT 1 FROM ProductRelevance WHERE UserID = $userID and ProductID = '$productID' and FacetValueID = '$value'";
	$result = mysqli_query($con,$sql);
	if (!$result)
	  {
	  die('Error: ' . mysqli_error($con));
	  }  


	if(mysqli_num_rows($result)) {
	  $sql =  "UPDATE ProductRelevance SET Relevance = Relevance + 1 WHERE UserID = $userID and ProductID = '$productID' and FacetValueID = '$value'";
	  $result = mysqli_query($con,$sql);
	  if (!$result)
	    {
	    die('Error: ' . mysqli_error($con));
	    }
	}
	else {
	  $sql =  "INSERT INTO ProductRelevance(UserID,ProductID,FacetValueID,Relevance) VALUES('$userID', '$productID', '$value', 1)";
	  $result = mysqli_query($con,$sql);
	  if (!$result)
	    {
	    die('Error: ' . mysqli_error($con));
	    }
	}


}




echo "OK";
mysqli_close($con);
?>