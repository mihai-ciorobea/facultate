<?php
$con=mysqli_connect("localhost","root","","faceted_search");
// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }


$facetValueIDs = $_POST[facetValueIDs];

if ( count($facetValueIDs) == 0 )
  return;

$list = "(";
foreach ($facetValueIDs as &$value) {
    $list = $list . $value . ',';
}
$list = substr($list, 0, strlen($list) - 1 );
$list = $list . ")";


$sql =	"DELETE FROM FacetValues WHERE FacetValueID in $list";

if (!mysqli_query($con,$sql))
  {
  die('Error: ' . mysqli_error($con));
  }
  
echo "OK";

mysqli_close($con);
?>