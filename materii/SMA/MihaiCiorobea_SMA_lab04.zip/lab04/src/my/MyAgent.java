package my;

import java.util.List;
import java.util.Random;

import base.Agent;
import blocksworld.Action;
import blocksworld.Blocks;

public class MyAgent implements Agent {

  private Blocks finalState;
  char agentName;

  public MyAgent(Blocks finalState, char name) {
    this.finalState = finalState;
    agentName = name;
  }

  @Override
  //playGround este doar mediu de pe masa nu si ce tine fiecare / el in brat
  public Action perform(Blocks playGround, Blocks.Block holding, boolean previousActionSucceeded) {


    if (playGround.equals(finalState)) {
      return null;
    }

    List<Action> possibleMoves;
    if (holding == null) {
      possibleMoves = pickupOrUnStack(playGround);
    } else {
      possibleMoves = putdownOrStack(playGround, holding);
    }

    int index = new Random().nextInt(possibleMoves.size());

    return possibleMoves.get(index);
  }

  private List<Action> putdownOrStack(Blocks playGround, Blocks.Block holding) {
    List<Action> possibleMoves = playGround.possiblePutDowns(holding);
    possibleMoves.addAll(playGround.possibleStacks(holding));

    return possibleMoves;
  }

  private List<Action> pickupOrUnStack(Blocks playGround) {
    List<Action> possibleMoves = playGround.possiblePickups();
    possibleMoves.addAll(playGround.possibleUnstacks());

    return possibleMoves;
  }

  @Override
  public String statusString() {
    return toString() + ": OK.";
  }

  @Override
  public String toString() {
    return "" + agentName;
  }

}
