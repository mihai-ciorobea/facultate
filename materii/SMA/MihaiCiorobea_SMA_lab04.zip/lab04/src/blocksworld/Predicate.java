package blocksworld;

import blocksworld.Blocks.Block;

public class Predicate {

  public static enum Type {
    ARMEMPTY,

    HOLD,

    ON,

    ONTABLE,

    CLEAR,
  }

  Type predicate;
  Block firstArg = null;
  Block secondArg = null;

  public Predicate(Type type) {
    if (type != Type.ARMEMPTY) {
      throw new IllegalArgumentException("Predicate has more than zero arguments");
    }
    predicate = type;
  }

  public Predicate(Type type, Block argument) {
    if (type == Type.ON) {
      throw new IllegalArgumentException("Predicate ON has two arguments");
    }
    if (type == Type.ARMEMPTY) {
      throw new IllegalArgumentException("Predicate ARMEMPTY has no arguments");
    }
    predicate = type;
    firstArg = argument;
  }

  public Predicate(Type type, Block firstArgument, Block secondArgument) {
    if (type != Type.ON) {
      throw new IllegalArgumentException("Predicate has less than two arguments");
    }
    predicate = type;
    firstArg = firstArgument;
    secondArg = secondArgument;
  }

  public Type getType() {
    return predicate;
  }

  public Block getArgument() {
    if (predicate == Type.ON || predicate == Type.ARMEMPTY) {
      throw new IllegalArgumentException("Predicate has not only one argument");
    }
    return firstArg;
  }

  public Block getFirstArgument() {
    if (predicate != Type.ON) {
      throw new IllegalArgumentException("Predicate has less than two arguments");
    }
    return firstArg;
  }

  public Block getSecondArgument() {
    if (predicate != Type.ON) {
      throw new IllegalArgumentException("Predicate has less than two arguments");
    }
    return secondArg;
  }

  @Override
  public String toString() {
    String ret = predicate.toString();
    switch (predicate) {
      case ARMEMPTY:
        break;
      case CLEAR:
      case HOLD:
      case ONTABLE:
        ret += "(" + firstArg.toString() + ")";
        break;
      case ON:
        ret += "(" + firstArg.toString() + ", " + secondArg + ")";
        break;
    }
    return ret;
  }
}
