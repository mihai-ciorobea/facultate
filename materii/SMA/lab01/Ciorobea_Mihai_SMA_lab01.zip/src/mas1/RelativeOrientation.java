package mas1;

public interface RelativeOrientation
{
	
}
