package org.mihigh.acc.project.communicator.communication;

public interface Node extends Runnable  {
}
