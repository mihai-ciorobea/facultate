package org.mihigh.acc.project.application;

public enum CommunicationType {
  DOPT, JUPITER,

}
