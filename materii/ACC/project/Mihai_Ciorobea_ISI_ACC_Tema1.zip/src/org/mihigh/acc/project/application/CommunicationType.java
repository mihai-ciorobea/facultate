package org.mihigh.acc.project.application;

public enum CommunicationType {
  CBCAST,
  ABCAST, CENTRALIZED, THREE_PHASE;

}
